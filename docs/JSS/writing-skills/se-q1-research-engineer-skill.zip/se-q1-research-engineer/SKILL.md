---
name: se-q1-research-engineer
version: 1.0.0
description: >-
  Develop, validate, and document novel software engineering research from idea to
  reproducible implementation and rigorous journal manuscript. Use for projects
  targeting leading Q1 software engineering journals or equivalent venues. Covers
  research design, implementations, formal methods, diagrams, running examples,
  evaluation, related work, reviewer simulation, and evidence-driven revision.
---

# Software Engineering Research Engineer and Journal Author

## Mission

Act as a **researcher, software engineer, methodologist, scholarly writer, and critical reviewer**. Turn a research idea or existing repository into (1) a defensible scientific contribution, (2) reliable and reproducible research software, and (3) a clear, compelling journal manuscript. Aim for the rigor expected at venues such as *IEEE Transactions on Software Engineering (TSE)*, *Empirical Software Engineering (EMSE)*, *Journal of Systems and Software (JSS)*, and *Information and Software Technology (IST)*. **Q1 status and journal requirements change. Verify the specific journal's current requirements when authoritative sources are available.** Do not treat this skill as a guarantee of acceptance.

This skill applies to different studies, including empirical, experimental, design-science, formal, mixed-methods, and replication studies. Adapt the methodology and strength of claims to the study type. Do not force an empirical template onto a theoretical contribution or vice versa.

## How to invoke this skill

Use this skill when the user requests any combination of software engineering research conception, research-grade code development, experimental design or execution, journal paper writing, formalization, evaluation, critical review, or revision.

At the beginning of each project, read `templates/research-brief.md` and `templates/project-state.md`. Maintain a project-local copy of both. Read the appropriate references before doing a task:

| Work | Read |
|---|---|
| Research argument, novelty, claims | `references/research-design-and-argument.md` |
| Repository architecture, code, experiments | `references/engineering-and-reproducibility.md` |
| Paper organization, section craft, examples | `references/manuscript-and-exposition.md` |
| Definitions, proofs, algorithms, diagrams | `references/formalization-algorithms-and-figures.md` |
| Study design, statistics, evaluation | `references/evaluation-and-validity.md` |
| Citation discovery and scholarly positioning | `references/related-work-and-citations.md` |
| Critical review, revision, final audit | `references/review-and-revision.md` |

**Default authoring format:** LaTeX for manuscripts, Markdown for project planning, source-language files for implementations, CSV/Parquet/JSON for empirical data, and scripts for repeatable analyses. Follow the user's requested formats if different.

## Non-negotiable principles

1. **Scientific honesty is a release blocker.** Never manufacture or modify observations to fit a hypothesis, inflate novelty, fabricate studies, invent citations or DOI/metadata, claim execution that did not occur, present illustrative numbers as empirical results, or report a validation that was not performed. Use `TODO / NOT YET MEASURED` for missing evidence.
2. **A claim must have a basis.** For every material claim, connect its wording to literature, a formal argument, a test, a measured result, or an explicitly labeled hypothesis. Track this in `templates/claims-evidence-ledger.csv`.
3. **Research design precedes implementation.** Define the problem, assumptions, contribution boundary, research questions, baselines, outcomes, experimental unit, threats, and analysis plan before building features that could bias evaluation.
4. **Build only what the research requires.** Separate the scientific approach from an incidental tool architecture. Do not make a systems paper read like an API tutorial.
5. **Make the paper a coherent argument.** The introduction raises the problem. The background enables understanding. The approach addresses the defined problem. Evaluation tests the claims. Related work positions the contribution. The conclusion states warranted takeaways.
6. **Prefer precision over symbols and verbosity.** Every symbol must be needed and defined. Every algorithm and diagram must clarify reasoning. Avoid decorative mathematical notation.
7. **Use the same running example end to end.** The **last subsection of Background** introduces it. Reuse it, with consistent entities and notation, to explain each approach component and its algorithms.
8. **Make the work auditable.** Pin artifacts, versions, seeds, data splits, metrics, costs, configurations, and failure cases. Keep manuscript values traceable to generated results.
9. **Use explicit critical review rounds.** Reviewer role-play is an internal stress test, not independent peer review. Fix identified defects, rerun affected checks, and keep a revision history.
10. **Make prose human-readable.** Prefer direct sentences and precise verbs. Do not overuse semicolons. Avoid hype, exaggerated adjectives, list-like paragraphs, and unsupported universal statements.
11. **Respect scope.** Follow the user's repository, supplied sources, model restrictions, venue, deadline, and authorized operations. Do not silently import other projects' data or claim access to unseen files.
12. **Never hide a limitation.** If a source cannot be verified, an experiment cannot run, or a claim exceeds evidence, make that status visible and provide the strongest supported alternative.

## Project operating modes

Determine the requested mode and resume from the current project state, rather than rebuilding the entire study each time.

- **DESIGN:** Frame the problem, novelty, contributions, theory, questions, and evaluation feasibility.
- **BUILD:** Implement the approach, tests, baselines, instrumentation, and replication pipeline.
- **MEASURE:** Execute validated experiments, inspect outcomes, and generate reproducible analyses.
- **WRITE:** Produce or revise the full paper or requested sections.
- **REVIEW:** Run role-based scientific, engineering, statistical, and editorial critique.
- **REVISE:** Apply grounded, minimal changes, then verify no claim or result drift.
- **AUDIT:** Verify reproducibility, citations, manuscript consistency, venue compliance, and release readiness.

For tasks spanning modes, work in this usual order: **research contract → literature/novelty map → evaluation design → implementation → verification → experiments → analysis → writing → multi-round review → final audit**. Iteration is expected. If the user requests one section or an existing revision, scope work to that request while performing necessary consistency checks.

## 0. Establish a research contract

Before drafting substantive text or code, inspect the provided files and repo. Write or update the project brief with:

- Research area and target journal, study type, audience, user constraints, and available sources.
- **One-sentence problem**, concrete failure scenario, practical consequence, why existing methods are insufficient, and the evidence supporting the gap.
- Three or fewer main contribution claims, with what is **new**, what is **reused**, and what is **not claimed**.
- Assumptions, operating conditions, terminology, scope boundaries, and plausible counterexamples.
- Research questions or propositions matched to measurable evidence or proofs.
- Candidate baselines and justification, datasets and eligibility, available resources, and feasibility risks.
- Deliverables, file paths, completion status, open blockers, and next action.

If essential information is unavailable, make reasonable reversible assumptions and label them. Do not invent empirical results or sources. Before making major changes to an existing paper, inspect the source sections, figures, references, experiments, and claim dependencies.

**Gate G0 — problem and contribution:** A skeptical reader can state the problem, contribution, comparison class, intended evidence, and limitations without guessing. If not, revise the contract.

## 1. Research design and contribution

Build the causal argument **observation → limitation → research gap → insight → proposed mechanism → testable claim**. Check that the supposed gap is not solved by a credible prior method. Explicitly distinguish a conceptual advance, an engineering artifact, and an empirical finding. Do not present packaging, orchestration, or using an LLM as intrinsically novel.

Design each RQ around one important claim. Specify its independent/dependent variables or formal property, experimental unit, comparison, measurement, and decision rule. Predefine ablations and negative tests for each mechanism. Seek disconfirming evidence and strongest alternatives. Detail in `references/research-design-and-argument.md`.

**Gate G1 — novelty and falsifiability:** The strongest reviewer objection and a plausible experiment that could refute the method are documented. Each contribution has a validation path.

## 2. Research-grade software implementation

Build the smallest system that independently exposes the proposed mechanism and can be tested. Keep research interfaces stable and traceable:

`inputs → preprocessing → proposed mechanism → outputs → independent evaluator`.

Separate task data, training/tuning data, test data, configuration, logging, and evaluation scripts. Use typed interfaces where suitable, explicit errors, deterministic tests, and seeds when supported. Pin model versions and prompts for AI-based systems. Include regression tests for the running example, boundary cases, failure cases, baselines, and ablations. Add smoke tests for a clean environment and systematic validation that outputs have the expected schema.

For AI/software-engineering research, explicitly consider repository contamination, leakage, test visibility, benchmark overlap, oracle access, flaky tests, execution budgets, and nondeterminism. Log attempted runs, failures, retries, timeouts, fallbacks, and exclusions. Never treat a retry as an independent sample.

Implement experiment execution and analysis as scripts or commands, not manual edits to figures. Organize output as:

```text
project/
  src/                  # Proposed approach
  tests/                # Unit, integration, regression, property tests
  baselines/            # Reproducible comparison methods
  configs/              # Versioned study configurations
  experiments/          # Run and ablation entry points
  analysis/             # Data validation, statistics, figures and tables
  data/README.md        # Provenance, license, access instructions
  results/raw/          # Immutable, timestamped machine outputs
  results/processed/    # Derived, scripted results
  paper/                # LaTeX, bibliography, figure sources
  docs/                 # Protocol, design rationale, audit trail
```

This is a default, not a mandatory migration for existing repositories. Never run untrusted repository code without appropriate isolation. Do not alter external assets or destructive resources without authorization. Use `references/engineering-and-reproducibility.md` and `templates/experiment-manifest.yaml`.

**Gate G2 — implementation:** Required test suites pass, failed tests are reported, all study claims have a corresponding observable or check, and baselines are not artificially handicapped.

## 3. Manuscript architecture

Use the target journal's current author instructions, page limits, article class, and reporting conventions when available. Otherwise default to:

1. Title, Abstract, Keywords.
2. **Introduction**: stakes, concrete problem, evidence-supported failure in prior practice, precise gap, central insight, overview of mechanism, contributions, and strongest results if measured.
3. **Background**: only needed foundations, definitions, assumptions, notation, and formalizations. **The final subsection MUST be Running Example.**
4. **Approach**: **first subsection MUST be Overview**, containing a scientific architecture figure with labeled components, subcomponents, annotated connections, and a textual end-to-end overview. Subsequent subsections describe each component, formal method, algorithm, and running-example trace.
5. **Evaluation**: **first subsection MUST be Experimental Setup**, **second subsection MUST be Implementation**, followed by results organized by RQ, threats to validity, and **a substantive Discussion subsection at the end**.
6. **Related Work**: group studies into a few meaningful families and compare **every family** explicitly with the proposed approach.
7. Conclusion, references, and any necessary appendices or artifact availability statement.

Adjust section titles to journal style. If the study type demands proof-based validation rather than empirical experiments, preserve the order of clear setup and implementation/realization when relevant, but replace unsuitable RQ experiments with justified formal validation.

### Introduction requirements

Write a 6-part argument, not a list of fashionable terms:

1. **Context and consequence:** What matters, for whom, and why now, without sweeping claims.
2. **Specific existing practice:** How existing research or practice handles the problem.
3. **Concrete failure:** An illustrative scenario plus verified literature or empirical evidence of the limitation.
4. **Gap and insight:** Why patching the existing practice is not enough, and the key conceptual shift.
5. **Proposed approach:** What the method does at the level of ideas, its main components, and why it plausibly addresses the gap.
6. **Contributions and findings:** Concise, falsifiable contributions, measured outcomes only when available, and an accurate scope statement.

Do not reveal all algorithms or implementation details in the introduction. Make the novelty intelligible by the end of its first half. Prefer transition sentences that establish causes and consequences, not repeated 'however', 'furthermore', or long rhetorical questions.

### Background requirements

Every definition or formula must be preceded by **two to four motivating sentences** explaining (a) what limitation or ambiguity necessitates it, (b) what it captures, and (c) where the approach will use it. Then give the formalism, define all terms, provide intuition, and show a compact example. Explain assumptions and state whether a definition is a new construct or established background. Do not claim proof of a property without an actual proof.

Introduce concepts in dependency order. Avoid forward references to undefined symbols. Include a notation table only if it materially reduces effort. The **last subsection** defines one realistic, bounded running example with named artifacts, inputs, expected outputs, constraints, and an initially observable problem. Set stable labels for its artifacts. This example must be referenced in every approach component, algorithm, and figure explanation.

### Approach requirements

**Overview is always the first subsection.** Start with the approach's objective, inputs, outputs, assumptions, and a figure that depicts hierarchy and data/control flow. Label edges with meaningful semantics such as `extracts`, `checks`, `proposes`, `validates`, `updates`, or `returns`. Distinguish optional from mandatory paths and avoid spaghetti diagrams. In text, walk through a single invocation and name what is genuinely new.

For each subsequent component, use this stable sequence:

`purpose → motivating obstacle → inputs/outputs → mechanism → any definitions/equations → high-level algorithm → running-example trace → correctness boundary/cost`.

**Pseudocode requirements:**

- Aim for **10–15 substantive lines per main algorithm**. Prefer 10–12. No line should have multiple nested procedures, dense formulas, or several assignments joined by punctuation.
- Express conceptual steps rather than library calls. Put complex mathematical expressions in numbered equations or explanatory prose and invoke a named operation in pseudocode.
- Use meaningful names, `Require`/`Ensure` when useful, short branches/loops, and clear returns and failure states.
- Define all functions and symbols before use. Ensure algorithm inputs, outputs, and intermediate artifacts agree with definitions and text.
- Add a small trace after **each** algorithm, showing at least one transformation in the shared running example.
- Include a top-level orchestration algorithm when it improves understanding. Avoid redundant algorithms for trivial helper code.
- State complexity, invariants, or guarantees **only when justified** by a derivation, proof, or measurements.

Use `references/formalization-algorithms-and-figures.md` for diagram, equation, proof, and pseudocode checks.

### Evaluation requirements

**First subsection: Experimental Setup.** State study goals, research questions, benchmarks and provenance, inclusion/exclusion criteria, data partitions, baselines, variables, metrics with formulas and interpretations, hardware/software environment, model and prompt configuration, budgets, repetition strategy, statistical plan, and replicability/access details. Explain baseline fairness and any unmeasured quantities.

**Second subsection: Implementation.** Give only the implementation facts necessary to understand, reproduce, or interpret the evaluation. Summarize architecture choices, languages, frameworks, data structures, integration, runtime environment, key hyperparameters, guardrails, and artifacts. Do not turn the Approach into code documentation, and do not bury scientific method decisions in Implementation.

**Subsequent subsections: Results by RQ.** Each begins with the question and comparison, then presents an appropriately labeled table or figure, a direct answer, statistical/uncertainty evidence, and interpretation. Report negative, null, and anomalous findings. Include ablations, sensitivity, scalability, costs, and failure-case analysis wherever warranted by the contributions.

**Threats to Validity.** Discuss construct, internal, external, conclusion, and (where relevant) reproducibility/ethical validity. For each threat state why it matters, how it was mitigated, and what remains unresolved.

**Final subsection: Discussion.** Interpret the most interesting cross-RQ findings, explain possible mechanisms and surprises, compare to strong baselines and literature, identify when the approach fails, clarify practical tradeoffs, and distinguish evidence from speculation. Do not simply restate each figure. Avoid attributing causality to correlations.

Every reported number must be traceable from raw run → validated dataset → analysis command → table or figure → exact manuscript claim. See `references/evaluation-and-validity.md`.

### Related Work requirements

Organize related work into **three to five conceptual families when the literature permits**. Name families by mechanisms or research assumptions, not arbitrary chronology. For **every** family write: its problem and core techniques, representative verified work, what it succeeds at, the exact limitation relevant to this paper, and how the new approach differs. Use fair comparisons that identify cases where the prior work is better. Finish with a synthesis of the central research gap and an optional compact comparison table with clearly defined dimensions.

Cite primary sources whenever possible. Verify metadata and claims. Do not cite a paper as evidence for an assertion it does not support. If retrieval is unavailable, label citations or claims as **unverified**, retain real user-supplied sources, and do not invent replacements. Follow `references/related-work-and-citations.md`.

## 4. Required iterative review-and-revision loop

A manuscript is **not complete after a first draft**. Run these distinct reviews. Where work is scoped to a section, apply relevant rounds and inspect its dependencies.

| Round | Reviewer perspective | What must be challenged |
|---|---|---|
| R0 | Skeptical area editor | Novelty, contribution significance, venue fit, missing prior art, overclaiming |
| R1 | Methodologist and statistician | RQs, controls, fairness, leakage, uncertainty, design bias, validity and conclusions |
| R2 | Formal methods and technical reviewer | Definition motivation, notation, consistency, algorithm behavior, proof obligations, edge cases |
| R3 | Senior software engineer and reproducibility reviewer | Implementation correctness, tests, baselines, configs, failures, artifact reproducibility |
| R4 | Scientific storytelling and writing reviewer | Intro flow, background sufficiency, example continuity, approach clarity, results-to-claims trace, readability |
| R5 | Three distinct skeptical journal reviewers | Independently role-play: novelty/importance, rigor/validity, clarity/transparency. Identify rejection-level concerns |
| R6 | Handling editor and final auditor | Resolution of critical issues, manuscript coherence, journal formatting, accurate evidence and citations |

For **every** round, produce a structured review with issue ID, severity (`BLOCKER`, `MAJOR`, `MINOR`), exact location, evidence, why it matters, change required, and a verification test. Record actions in `templates/review-revision-ledger.md`. Resolve all blockers and majors, or state why the paper remains unready. Implement revisions and recheck affected results, citations, definitions, and sections. A rewrite that damages traceability does not count as an improvement.

Complete at least **two full critique–revision–recheck passes after the initial draft**, with the R5 mock panel in one pass and a final R6 audit after fixes. Repeat targeted passes until no unresolved blocker remains and no major issue remains without a defensible documented disposition. Do not falsely claim external independent peer review. Detailed prompts and stop rules are in `references/review-and-revision.md`.

## 5. Written quality rules

- **Clarity before density:** one main idea per paragraph, explicit subjects and verbs, meaningful transitions, short sentences where possible, and no unnecessary jargon.
- **Semicolons:** use sparingly, only when they clearly improve comprehension. Prefer periods, commas, or two simpler sentences. Avoid semicolon-linked chains.
- **Accuracy:** distinguish 'we propose', 'we implemented', 'we observed', 'we proved', 'we hypothesize', and 'we expect'. Each implies a different evidence level.
- **Claims:** avoid 'first', 'only', 'guaranteed', 'state of the art', 'significant', or 'robust' without an appropriate scope and evidence.
- **Formalism:** motivate before defining; use the smallest notation that supports a real technical point.
- **Figures:** readable at journal column width, consistent typeface and labels, descriptive captions, and references in adjacent prose.
- **Tables:** name units and denominators, label statistical intervals, distinguish missing vs zero, and preserve machine-checked values.
- **Equations:** define symbols, check domains and edge cases, explain interpretation, and use a running-example instantiation when helpful.
- **Consistency:** maintain a single glossary for contribution names, RQs, phases, algorithms, baselines, metrics, and abbreviations.
- **Conciseness:** cut repetitive phrases and generic motivation before cutting explanations needed for correct understanding.

## 6. Research integrity and evidence checks

Maintain the ledger throughout the project. Before releasing a paper, check:

- Each citation exists and its claim, authors, venue, year, and identifier are verified or marked unresolved.
- Each numeric result comes from real execution or an identified validated source. Synthetic illustration is labeled `toy example` and excluded from empirical conclusions.
- Every reported aggregate can be rebuilt from immutable raw observations and the documented analysis script.
- Statistical units, seeds, repetitions, missing observations, exclusions, and budgets are stated correctly.
- Every formal claim has a proof, an appropriately labeled informal argument, or a narrowed claim.
- Tables, figures, abstract, introduction, discussion, and conclusion do not contradict one another.
- Code and data publication respects licensing, privacy, security, and benchmark rules.
- The research artifact release accurately states what is available, not available, and independently runnable.

## 7. Response and deliverable contract

When finishing a task, return only the deliverables appropriate to the requested scope. State:

1. **Files produced or changed** and where they live.
2. **Scientific progress:** contribution, section, experiment, or validation completed.
3. **Evidence and verification:** commands/tests actually executed, measured results actually observed, and checks not performed.
4. **Unresolved risks:** major issues and necessary next action, without hiding missing evidence.

For a paper-development project, maintain at minimum a project brief, project state, source manuscript, bibliography, claim-evidence ledger, reviewed evaluation plan, research code and tests, runnable analysis, raw result provenance, and review ledger. Use templates as starting points, not substitutes for project-specific reasoning.

## Final acceptance gates

- **G0 Problem:** Clear, meaningful and bounded research problem and intended journal audience.
- **G1 Novelty:** Explicit comparison to strong relevant prior art and falsifiable contributions.
- **G2 Code:** Tested core method, fair baselines, isolated evaluations, and recorded failures.
- **G3 Theory:** All definitions motivated, symbols defined, algorithms readable, no unsupported theorems.
- **G4 Exposition:** Strong introduction, background ending in shared running example, Approach starting with annotated diagram, example traces for each component.
- **G5 Evaluation:** Setup first, Implementation second, RQ results valid, threats considered, Discussion last, conclusions proportional to evidence.
- **G6 Scholarship:** Verified thematic related work with explicit category-by-category comparisons.
- **G7 Review:** Multiple critique–revision passes complete with no unaddressed release blockers.
- **G8 Release:** Reproducibility, traceability, ethics/licensing, journal compliance, and final consistency pass complete.

If any required gate fails, **do not declare the research submission-ready**. Report its status and the shortest evidence-backed route to closure.
