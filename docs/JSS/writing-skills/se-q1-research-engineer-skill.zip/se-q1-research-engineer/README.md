# SE Q1 Research Engineer — portable agent skill

This is a reusable **research and research-software development skill** for an AI coding/writing agent. It is a structured workflow and quality standard, not a guarantee of journal acceptance. It prioritizes scientific honesty and reproducible evidence.

## Contents

- `SKILL.md` — core behavior, mandatory manuscript architecture, review rounds, and completion gates.
- `references/` — deeper operating instructions for argument design, coding, formalization, evaluation, scholarship, and revision.
- `templates/` — reusable brief, project state, evaluation plan, experiment manifest, claims ledger, review ledger, traceability matrix, journal-paper LaTeX skeleton, reviewer scorecard, and starter prompt.

## Installation

Copy this **entire folder** into your agent's supported skills directory. Rename the folder `se-q1-research-engineer` if necessary. Common conventions are `.cursor/skills/se-q1-research-engineer/`, `.claude/skills/se-q1-research-engineer/`, or `.agents/skills/se-q1-research-engineer/` within a project. Verify your specific tool's current skill discovery rules. The `SKILL.md` file must remain at the root of the skill folder, with `references` and `templates` adjacent to it.

To use without skills support, provide `SKILL.md` and the referenced files as project instructions. The agent should consult the supporting files when a task matches their topic.

## First invocation

Copy and adapt `templates/agent-starter-prompt.md`. Example:

> Apply the `se-q1-research-engineer` skill to my repository. We are preparing a JSS paper on [problem]. Start in DESIGN mode, audit the research gap and proposed mechanism, then create an evaluation plan. Use only our authorized sources. Do not modify existing measurement files.

The agent should populate `research-brief.md` and `project-state.md` in the project. Reuse and update these between sessions rather than inventing project history.

## Non-negotiable manuscript ordering

1. Introduction.
2. Background, with motivated definitions and a **final Running Example subsection**.
3. Approach, beginning with **Overview and annotated component/subcomponent diagram**, followed by readable **10–15-line** algorithms and example traces.
4. Evaluation, starting with **Experimental Setup**, then **Implementation**, followed by RQs, threats, and a substantive final **Discussion**.
5. Related Work, grouped by mechanism, with explicit comparisons for every group.
6. Conclusion.

## Safety and integrity

The agent must not present generated toy numbers as empirical results or alter observations to improve a paper. It must cite checked sources, report tests actually executed, preserve experimental provenance, and flag evidence gaps. Review rounds are internal role-play unless actual external reviewers are involved.
