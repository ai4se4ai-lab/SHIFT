# Literature review, citation integrity, and comparison to prior work

## 1. Discovery and verification

Use sources authorized by the user and, when available, primary publisher pages, digital libraries, preprints with corresponding versions, source artifacts, and citation databases. Search by **problem**, **mechanism**, **assumption**, and **benchmark**, including synonyms. Identify strong recent work and seminal foundations. Search related venues, not only one journal or a narrow keyword.

For each candidate paper, verify:

- Real title, authors, year, venue, identifier, and paper version.
- What the method actually assumes and solves.
- Which data, evaluation, and claims are reported.
- Whether a quoted limitation is genuinely stated or follows from a specific verified method property.
- Whether a work supersedes an earlier preprint or shares an artifact with another publication.

A bibliography entry is not evidence that its contents were read. If only a title or abstract is accessible, limit claims accordingly. If sources cannot be retrieved, do not guess the paper details. Mark verification status explicitly and seek supplied files when needed.

## 2. Literature taxonomy

Group prior work by **what it does**, not only by application name. Possible families might include:

- Dependency- and static-analysis approaches.
- History-, graph-, or trace-based approaches.
- Retrieval- or LLM-based reasoning approaches.
- Agentic/tool-using approaches.
- Specification-, verification-, or model-driven approaches.

These are examples only. Derive categories from the actual relevant literature. Aim for **three to five** coherent groups, merging sparsely populated groups and separating substantively different assumptions.

## 3. Mandatory group-by-group paragraph pattern

For *each* group, write:

1. **Focus and mechanism:** what the family attempts and how.
2. **Representative work:** specific verified primary sources.
3. **Strength:** what the family demonstrably does well, without caricature.
4. **Gap relative to our question:** a precise boundary or unresolved assumption.
5. **Comparison:** which elements of our approach overlap, replace, generalize, or complement it. Explain conditions where prior techniques remain stronger.

End the section with a synthesis comparing the primary assumptions and the actual scientific contribution. Do not end by simply repeating "Unlike prior studies, we ..." three times.

## 4. Comparison matrix template

| Family / representative work | Unit of analysis | Key assumption | Mechanism | Evaluated outcome | Relation to this paper | Evidence source |
|---|---|---|---|---|---|---|
| Family A | ... | ... | ... | ... | extends / differs / complements | verified page or section |
| Family B | ... | ... | ... | ... | ... | ... |
| Proposed approach | ... | ... | ... | measured or planned | --- | study artifact |

Comparison dimensions must be meaningful and fair. Mark `not reported`, `unknown`, or `not directly comparable` rather than inventing a negative result for prior work.

## 5. Citation practices

- Prefer primary methods and empirical evaluations over secondary citations for specific technical claims.
- Cite a paper at the statement it supports, not by clustering citations at the paragraph end.
- Verify whether comparative numerical results use comparable data, metric, and budget before quoting them.
- Avoid blanket claims such as "all existing work assumes ..." unless an actual review justifies them.
- Distinguish another paper's **acknowledged limitation** from a **limitation inferred by our analysis**.
- Avoid citing your own work disproportionately when more direct prior art exists.
- Do not reconstruct BibTeX metadata from a guess. Keep unresolved entries as explicit placeholders in a working ledger, not fabricated records.

## 6. Reviewer's literature attack

Ask:

- Which paper would make the proposed contribution seem least novel?
- Which family uses a different name for essentially the same mechanism?
- Is the evaluation missing the strongest prior baseline?
- Have we compared mechanisms and assumptions rather than marketing labels?
- Are groups mutually intelligible without arbitrary overlap?
- Could a prior author recognize their work from our description and agree it is fair?

Resolve these questions before presenting the related work as finalized.
