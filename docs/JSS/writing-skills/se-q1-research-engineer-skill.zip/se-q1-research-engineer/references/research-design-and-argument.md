# Research design, novelty, and argumentation

## 1. Diagnose the research contribution

Start from a specific failure, not a technology. Use this pattern:

> Under [context], existing [method family] assumes [assumption]. In [scenario], this assumption fails because [mechanism]. This causes [measurable consequence]. We investigate [hypothesis or insight] by [proposed mechanism], evaluated against [strong alternatives] using [evidence].

Validate each field with examples, citations, or data. If the mechanism cannot be articulated without tool-specific terms, extract the scientific idea. Distinguish five potential contribution types:

- **Problem discovery:** documented behavior or failure mode that changes what the community should study.
- **Theory or formalization:** a new abstraction that clarifies a property, enables reasoning, or yields verifiable guarantees.
- **Method:** a mechanism that makes a testable difference relative to a strong comparison class.
- **Empirical study:** high-quality evidence that resolves an important uncertain question.
- **Artifact:** a research-enabling implementation. Treat it as the primary contribution only if justified by the target venue and study goals.

A paper can combine types, but do not claim novelty for all of them by default.

## 2. Novelty comparison protocol

1. Identify the **nearest neighbors**, including methods that solve the same problem without using the same terminology.
2. Build a table with columns: source, verified claim, core assumption, inputs, outputs, mechanism, evidence, scope, and difference.
3. Ask whether the new method is merely a different implementation of an existing mechanism.
4. Test whether a simpler method using the same inputs achieves similar benefits.
5. Phrase novelty at the **smallest defensible boundary**: e.g., a new compatibility relation under stated assumptions, not a universal solution to AI-assisted development.
6. Write the strongest reviewer counterargument and what evidence would resolve it.

Check both direct baselines and adjacent lines of work. An absence of prior papers in a narrow keyword search does not establish novelty.

## 3. Argument dependency graph

Keep the manuscript's scientific claims in an explicit graph:

```text
Observed problem ──supports──> Research gap
Prior work ──bounds──> Research gap
Research gap ──motivates──> Approach objective
Approach mechanism ──supports──> Contribution claim
Formal property ──supports──> Theoretical claim
Experiment/RQ ──tests──> Empirical claim
Threat/limitation ──bounds──> Claim
```

For every conclusion or abstract claim, trace a path to its supporting proof or experiment. For every major mechanism, identify which problem it addresses and which evaluation tests its value. Unconnected claims and features should be rewritten, removed, or justified.

## 4. RQ construction

Use RQs that are **non-overlapping, answerable, consequential, and aligned to contributions**. A generic evaluation matrix is:

| Claim dimension | Example question | Required evidence |
|---|---|---|
| Effectiveness | Does the proposed method improve the target outcome? | Strong baselines, paired tasks, appropriate metrics and uncertainty |
| Attribution | Which components cause or explain improvement? | Ablations, matched conditions, sensitivity |
| Reliability | Where and how often does it fail? | Repetitions, failure taxonomy, timeouts, retries, null cases |
| Generalizability | Does it hold outside tuning contexts? | Disjoint projects, temporal or cross-domain validation |
| Practicality | Is improvement worth extra cost and complexity? | Runtime, compute, engineer effort or human burden, hardware budgets |
| Formal validity | Does a claimed invariant or guarantee follow? | Explicit assumptions, proof or exhaustive check within justified bounds |

Not every study needs six RQs. Prefer two to four substantive RQs, each with a distinct role.

## 5. Identify threats before seeing results

For each RQ, write down:

- Data-generation process and possible selection bias.
- Comparison conditions, equal-access assumptions, and tuning budgets.
- Leakage or contaminated evaluation labels.
- Measurement error and oracle validity.
- Non-independence at project, benchmark, model, participant, or run level.
- An alternative hypothesis that could generate the same results.
- A plausible negative result and how it would change the contribution claim.

Precommit to primary metrics and planned comparisons when possible. If exploratory analyses emerge later, label them exploratory instead of retroactively claiming they were confirmatory.

## 6. Problem-to-paper crosswalk

| Element | Where it appears |
|---|---|
| Stakes, concrete problem | Introduction opening |
| Gap evidence and nearest prior methods | Introduction and Related Work |
| Precise entities and assumptions | Background |
| Reusable failure scenario | Background's last subsection, Running Example |
| Scientific mechanism | Approach Overview and component subsections |
| Key formal relations | Motivated Background definitions and Approach equations |
| Tests and competing explanations | Evaluation setup, RQs, ablations |
| Warranted interpretations | Discussion |
| Limitations and scope boundaries | Threats to Validity, Discussion, Conclusion |

## 7. Reviewer challenge card

Before drafting, answer these questions in four sentences each:

1. What would a strong reviewer say is **already known**?
2. Why is the proposed mechanism not a minor variation?
3. What outcome would falsify the principal claim?
4. Which baseline is most likely to make our advantage disappear?
5. What does the method require that a practitioner may not have?
6. What changes if the key assumption is violated?

Use these answers to improve the design rather than to write defensive rhetoric.
