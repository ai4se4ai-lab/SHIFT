# Multi-round scientific peer-review simulation and revision protocol

## 1. Independent review roles within the agent

Perform **role-separated critiques** using distinct criteria and an explicit evidence ledger. These are multiple perspectives from the same AI workflow, **not independent human reviewers** and not evidence of acceptance. When a real reviewer report is supplied, prioritize its exact points, preserve identifiers, and distinguish reported criticism from self-generated critique.

### R0: Area editor — significance and journal fit

Ask whether the problem is important to the journal's audience, prior art is correctly positioned, contribution is non-incremental, conclusions are properly bounded, and the paper has a coherent thesis. Flag scope creep and unexplained assumptions.

### R1: Research methodologist and statistician

Reconstruct each RQ from its protocol. Check baseline fairness, data leakage, unit of analysis, missing data, sample selection, statistical assumptions, effect size and intervals, repeated observations, human labeling, threats, and whether interpretations follow the evidence. Challenge surprisingly regular or suspiciously perfect results by inspecting provenance rather than editing observations.

### R2: Technical/formal reviewer

Attempt to execute each algorithm mentally on normal, empty, adversarial, and edge-case inputs. Verify symbols and relations, definitions motivated in prose, algorithm–implementation consistency, guarantees and proof assumptions, complexity, and whether each component is necessary.

### R3: Research software engineer

Read the actual code and tests. Validate module contracts, correctness, missing branches, input schema, reproducibility, deterministic fixtures, baseline parity, timeout/retry policy, data handling, dependency versions, and security boundaries. Run the supplied tests if possible.

### R4: Expert scientific writer

Read introduction and conclusion first, then background and approach. Diagnose logical discontinuities, unexplained jargon, redundant passages, overly dense formulas or algorithms, diagram clutter, missing running-example traces, figure/caption mismatch, ambiguous pronouns, and semicolon overload.

### R5: Mock three-reviewer panel

Create three separate structured reviews:

- **Reviewer A — Novelty, significance, prior work.** Main task: find closest competitor, identify incrementalism, question impact.
- **Reviewer B — Technical depth and empirical rigor.** Main task: challenge definitions, method, experiments, tests, statistical validity, and negative cases.
- **Reviewer C — Transparency, clarity, replicability, usability.** Main task: check whether an unaffiliated team could understand, reproduce, and trust the results.

Each reviewer writes a concise summary, strengths, **at least three concrete weaknesses where warranted**, severity, questions to authors, and a recommendation category (`not ready`, `major revision`, `minor revision`, `ready for editor check`). Never fabricate reviewer identities, institutions, or real peer-review outcomes.

### R6: Handling editor / final audit

Verify all `BLOCKER` and `MAJOR` findings are fixed or justified as unresolved. Reconcile cross-section references, abstract and conclusion claims, original results, figure/table totals, captions, bibliography, LaTeX build, artifact metadata, and journal formatting. State readiness conditional on actual checks.

## 2. Issue report schema

Use this exact conceptual format:

```text
ID: R2-04
Severity: MAJOR
Location: Approach §4.2, Algorithm 2, line 7
Issue: The algorithm can return an unverified candidate when the constraint set is empty.
Why it matters: The text claims every returned candidate satisfies the stated check.
Evidence: Branch condition in the algorithm and missing code test.
Required change: Clarify the empty-set semantics and align control flow and contract.
Verification: Add unit test for empty constraints, recheck Definition 3 and Conclusion.
Status: OPEN
```

Use real locations and evidence in a real review. This snippet is an illustrative review item, not a claim about the user's code.

## 3. Revision loop

**Pass 1 — scientific architecture and validity.** Complete R0, R1, R2, and R3 as relevant. Collect defects in the issue ledger, group duplicates, prioritize blockers, apply controlled changes, and rerun affected checks.

**Pass 2 — exposition and adversarial panel.** Complete R4 and the R5 three-reviewer simulation. Address every substantive objection, including paper-level reframing if novelty or validity fails. Re-run relevant code, statistical analysis, bibliography, and cross-reference checks.

**Pass 3 — verification and editorial pass.** Complete R6, inspect residual weaknesses with fresh issue IDs, enforce writing rules, and build final output. Repeat targeted reviews where unresolved major problems remain.

A pass is complete only after critique, an actual revision, and **a verification step**. Repeatedly generating nearly identical feedback without revising is not progress.

## 4. Correct order of revision

1. Research honesty, evidence provenance, and fundamental validity.
2. Overclaimed or unsupported contributions.
3. Core method or algorithm correctness.
4. Evaluation design and controls.
5. Manuscript organization and logical argument.
6. Related-work completeness and fairness.
7. Figure, equation, terminology, and LaTeX consistency.
8. Sentence-level prose, concision, punctuation, and presentation.

Do not polish weak evidence into plausible-sounding claims. If a result cannot be substantiated, remove it, qualify it, or mark it pending with a concrete evidence requirement.

## 5. Revision safety and evidence conservation

- When revising an existing manuscript, **preserve all observed measurements and cited provenance** unless a verified source correction requires a change.
- Track altered text in diffs. When the user requests tracked LaTeX, preserve exact source numbers, definitions, and citation keys unless changes are authorized and justified.
- Any change in metric definition requires recomputing affected analyses and updating every dependent table and claim.
- When a definition changes, revisit pseudocode, running-example traces, implementation contracts, proofs, and evaluation labels.
- When a baseline changes, recheck fairness, result comparability, and conclusion scope.
- Avoid blanket rewriting that conceals meaningful changes or introduces ungrounded novelty claims.

## 6. Stop criteria and readiness language

**NOT READY** if any blocker remains, a central claim has no evidence, a citation is fabricated, a key baseline comparison is unfair, the method is inconsistent with implementation, or numerical outputs are not traceable.

**NEEDS MAJOR WORK** if substantial method, evaluation, or argument limitations remain but no integrity breach is present.

**READY FOR SUBMISSION AUDIT** when no blockers or unresolved major issues remain, required tests and paper builds pass, sources are checked, and every claim is bounded. The editor still decides whether the work meets a journal's standards.

At each review completion provide: severity summary, files changed, fixes made, validation actually run, unresolved issues, and next smallest action.

## 7. Prompt cards for automated role-play

**Novelty adversary:**
> You are a skeptical senior reviewer of a leading SE journal. Identify the closest established solutions and determine whether the scientific mechanism is substantively different. Locate overclaims. Present the strongest rejection arguments with exact evidence and feasible remedies.

**Methodology adversary:**
> Inspect RQs, unit of analysis, baselines, experimental control, leakage, repeated trials, uncertainty, missing results, costs, and the claims-evidence chain. Identify tests that would falsify the authors' preferred explanation.

**Formal/algorithm adversary:**
> For every symbol, definition, invariant, and pseudocode step, check need, precise meaning, termination, corner cases, compatibility with implementation, and running-example continuity. Identify unsupported proofs or complexity statements.

**Clarity adversary:**
> Read as a knowledgeable SE researcher unfamiliar with this particular technique. List each place where the argument jumps, a term is undefined, a sentence is overlong, a diagram is hard to read, a component lacks example illustration, or punctuation reduces readability.

**Reproducibility adversary:**
> Assume access only to the paper and released artifacts. Attempt to reconstruct preprocessing, configurations, baselines, runs, metrics, statistical analysis, and reported numbers. Identify every missing input and untestable claim.
