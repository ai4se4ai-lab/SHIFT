# Empirical evaluation, statistical rigor, and validity

## 1. Evaluation is a test of claims, not a showcase

Before any experiments, write a locked or versioned **evaluation protocol**. For each RQ document:

| Item | Required content |
|---|---|
| Scientific claim | Exact assertion that the RQ probes |
| Outcome/estimand | What quantity is being estimated, and for what target population |
| Experimental unit | Task, project, developer, issue, model, or independent run |
| Intervention | What mechanism is enabled, changed, or removed |
| Comparator | Why each baseline is competitive and fairly configured |
| Dataset | Source, inclusion/exclusion, deduplication, version, license |
| Measurement | Operational definition and oracle, numerator, denominator, units |
| Budget and repetition | Time, samples, seeds, fixed inference budget, retry policy |
| Analysis | Paired/unpaired method, interval, effect size, correction, heterogeneity |
| Validity risks | Leakage, confounding, dependence, missingness, and robustness checks |
| Decision rule | What evidence would support, weaken, or refute the claim |

Do not decide significance tests after seeing results without disclosing exploration. Do not use a statistical test that assumes independent samples when tasks are nested in projects or models.

## 2. Mandatory ordering and content

### Evaluation 1 — Experimental Setup

Include:

- RQs and study hypotheses/propositions. Clarify confirmatory versus exploratory tests.
- Benchmark or corpus origin, dates/versions, selection process, project and task counts, exclusion reasons, and data leakage controls.
- Control conditions, strongest recent baselines, published versus reproduced result status, and baseline tuning parity.
- Experimental factors, independent unit, repeated-measure structure, randomization or matching, replication count, compute budget, and stopping policy.
- Metrics: formula, interpretation, success/failure policy, primary/secondary status, and denominator.
- Oracle and human-label protocol, where relevant. Include raters, blinding, adjudication, agreement, and calibration rules.
- Hardware, software, runtime, API/model versions, prompts, seeds, and important config values.
- Statistical tests and assumptions, effect sizes, confidence intervals, multiple comparisons, missingness plan, subgroup analysis, and analysis code location.

When space is constrained, put detailed inventory in an appendix or online artifact, but leave enough information in the main text to evaluate credibility.

### Evaluation 2 — Implementation

Summarize implementation **only at the level needed to understand cost, feasibility, and replicability**: runtime languages, major dependencies, architecture mapping, storage and retrieval choices, key environment, execution workflow, parameter selection, and reproducibility instructions. The Approach remains conceptual. Explain what was built rather than re-presenting the paper's claimed novelty.

### Evaluation 3+ — Results organized by RQ

For each RQ use the pattern **question → design → evidence → answer → interpretation → limitations**. Tables should include sample size, units, denominators, and uncertainty where relevant. Pair effect estimates with uncertainty and raw distributions or complementary plots. Avoid summary statistics that hide strong per-project variation.

### Threats to Validity

Use construct, internal, external, and conclusion validity, plus replication or ethical issues as applicable. For each: the threat, why this study is affected, what was done, what remains uncertain, and the expected direction of bias when estimable.

### Evaluation final subsection — Discussion

Synthesize findings across RQs. Analyze mechanisms, surprising outcomes, subgroup heterogeneity, failures, deployment costs, and the tradeoff between benefit and complexity. Explain non-results without dismissing them. Compare findings with verified literature and discuss implications that remain within the evidence boundary.

## 3. Baseline and ablation standards

- Compare to strong **same-task** baselines, not only a trivial heuristic or an older unmaintained system.
- Include an appropriately tuned simple baseline. A complex system should demonstrate value beyond additional tokens, compute, retrieval, or access to privileged information.
- Keep inputs, models, test leakage policies, data cleaning, budgets, and evaluation oracles comparable, or disclose differences and narrow claims.
- Reproduce a prior baseline honestly. If reimplementation differs, log changes and perform sanity validation.
- Choose ablations that remove a **scientific mechanism**, not arbitrary code modules.
- Evaluate interaction effects when components are coupled. Do not infer additive causal contribution from one-at-a-time ablations without justification.
- Include negative controls or sanity checks when a shortcut, leakage, or spurious association is plausible.

## 4. Recommended methodological families

These are options, not mandatory choices:

| Outcome | Typical analysis candidates | Caveats |
|---|---|---|
| Paired binary task success | Paired difference with interval, McNemar for paired decisions, hierarchical model where nested | Same tasks and denominators, account for repeated models |
| Per-task continuous score | Paired bootstrap CI, permutation test, robust paired comparison | Handle skew and multiple runs per task |
| Runtime/latency | Distribution, quantiles, survival/censored analysis for timeouts | No arbitrary deletion of timeout runs |
| Multiple project benchmarking | Per-project effect and hierarchical or clustered uncertainty | No pseudoreplication from task clustering |
| Human ratings | Inter-rater agreement, ordinal methods, rater effects | Raters and labels are not automatically independent |
| Coverage, recall, precision | Clear gold labels, unit-level counts, intervals | Missing/ambiguous labels and partial adjudication must be reported |
| Resource cost | Money, compute, tokens, wall time, throughput | State environment, pricing date if relevant, accounting basis |

Select tests on the basis of estimand and design. Do not reflexively use a p-value threshold. For multiple RQs/contrasts, predefine primary comparisons and use a justified adjustment or transparent exploratory reporting. Report effect magnitude and practical relevance, not just statistical significance.

## 5. Sample size and repeated measures

Before execution, justify why the sample can detect or characterize the effect of interest. Prefer an a priori power calculation where meaningful, a precision target, or an explicit feasibility-bound design. Avoid claiming adequately powered hypothesis tests without support.

Be precise about:

- **N tasks** vs **N unique projects** vs **N distinct models** vs **N attempts**.
- Whether multiple seeds or attempts on one task contribute independent evidence.
- Whether model-family similarity, common benchmarks, or shared human raters create clustering.
- Whether repeated trial failures are part of the outcome or valid exclusions.

For a panel of models on the same tasks, consider matched-task comparisons and nested variance rather than treating model-task rows as IID. Keep a transparent table of independent units and repeated observations.

## 6. Measurement and human labeling

For human annotation report:

1. Item selection and unit of labeling.
2. Operationalized rubric and codebook.
3. Rater training and independent rating process.
4. Number of raters and blinded or non-blinded status.
5. Disagreement handling and adjudication criteria.
6. Agreement statistic and why it is appropriate.
7. Sampling and representativeness limits.
8. Label, tool, and scorer provenance.

Do not infer recall from manually verified positive findings alone. Recall needs a defined set of relevant items, including misses, from an appropriate gold or reference process. For detected violations, distinguish genuine underlying defects from conversion artifacts and verification artifacts.

## 7. Results provenance pipeline

```text
immutable raw attempts
   ↓ schema + integrity checks
eligible observations (with exclusions log)
   ↓ unit and denominator validation
paired or clustered analysis dataset
   ↓ versioned analysis script
metric tables + intervals + plots
   ↓ automated crosscheck
LaTeX tables/figure files + claim ledger
```

Each result row should carry study/experiment ID, task and project IDs, baseline/method, model/config IDs, seed, outcome, status, cost, artifact path, timestamp, and validation verdict. For reported comparisons archive the exact inclusion masks and denominator counts.

### Table and figure audit

- Are all numbers derived using code and rounded consistently?
- Are uncertainty intervals calculated at the correct independent unit?
- Are ties, failures, timeouts, missing responses, and invalid outputs accounted for?
- Is the same baseline definition used in all tables?
- Does the textual claim match the figure's comparison, unit, and confidence?
- Are claimed percentages explicitly relative or percentage-point differences?
- Could a reader rederive the key result from the artifact?

## 8. Failure analysis and interpretation

Treat unexpected cases as evidence, not embarrassing exceptions. Use a consistent failure taxonomy, sample cases with an explicit selection rule, and connect causes to logs or artifacts. Compare failure types across methods when possible. Distinguish true method failure from infrastructure error, invalid benchmark, impossible task, or unclear oracle.

Discuss whether gains result from better reasoning, more context, more compute, benchmark artifacts, or accidental privileged information. Claims about causal mechanisms need isolating experiments, not only speculative explanations.

## 9. Prohibited shortcuts

Never create plausible-looking results to populate a draft. Never change CSV values to make performance appear more organic. Never fabricate independent raters, agreement coefficients, ablation outputs, or baselines. Never silently choose a subset after seeing favorable results. Never hide null results or replace a failed run with a successful retry without counting policy. If evidence is absent, supply study design, scripts, empty tables, and transparent status labels.
