# Manuscript architecture and scientific exposition

## 1. Storyboard before prose

Write a **one-page paper storyboard** containing:

- Central claim, contribution boundary, intended audience.
- One vivid failure scenario and the evidence showing why it matters.
- Three key figures in order: problem illustration, approach diagram, main result or argument.
- A paragraph-by-paragraph introduction map.
- Definition dependency order, shared running example, and algorithms needed.
- RQ-to-figure/table map, planned conclusion, and strongest limitation.

Evaluate the logical sequence before expanding LaTeX.

## 2. Introduction quality requirements

Paragraphs should form a continuous argument. A suitable structure is:

| Move | Reader's question | Writer's job |
|---|---|---|
| Context | Why should I care? | Identify real consequence, not generic AI popularity |
| Current practice | What is normally done? | Describe a credible state of practice with citations |
| Problem | What breaks, specifically? | Give observable failure and conditions |
| Gap | Why does prior work not already solve it? | Name unresolved assumption and supporting sources |
| Insight | What changes conceptually? | Introduce one high-level idea with intuitive causal reason |
| Solution | What is proposed? | Give simple component-level overview without implementation minutiae |
| Evidence/contributions | Why believe the paper matters? | State measured evidence if available and bounded contributions |

A good introduction can combine or split moves, but cannot omit the logic. Include a direct research gap statement. Ensure that a skeptical reader can tell exactly what is new. Write the abstract **after** results are stable. Abstract structure: problem, gap, mechanism, study design, actual strongest results, limitation or implication. Never insert placeholders that resemble measured outcomes.

## 3. Background design and the running example

The background should be a selective dependency tree. Keep concepts that the approach will use, remove a general tutorial on tangential ideas. Each background subsection should:

1. Motivate why the concept is needed.
2. Give precise informal intuition.
3. Formalize only if it enables subsequent reasoning.
4. Explain symbols, conditions, and assumptions.
5. Give one compact example, tied to the running example when possible.

**Make the last subsection `Running Example`.** Choose a case with a few concrete entities, e.g., issue `I-17`, modules `A` and `B`, a failing test `T-3`, a patch candidate `P`, and a verification condition `C`. These are illustrative names, **not results**. Introduce a precise input, current failure, desired outcome, constraints, and ground truth or oracle status. Ensure the same fixture can drive unit or integration tests when possible.

For each Approach component, include an explicitly signposted continuation, e.g., "In the running example, the provenance analyzer links I-17 to ...". Avoid suddenly changing example entities or hiding complexity in a contrived case. If the example is simplified, state what it omits.

## 4. Approach component writing pattern

Use the same order for every significant component:

**Why needed.** One paragraph connecting a problem to this mechanism.

**Contract.** Define inputs, outputs, assumptions, and relations to previous components.

**Mechanism.** Explain steps and any genuine insight. Introduce equations where they clarify relationships.

**Algorithm.** Provide readable 10–15-line high-level pseudocode where the procedure matters. Do not duplicate code-level details in paragraphs.

**Example.** Trace the running example through the component using specific intermediate data and outputs.

**Properties.** State invariants, failure behavior, computational cost, tradeoffs, and limits only with warranted reasoning.

## 5. Evaluation exposition pattern

For every RQ, organize text as:

1. A short question-specific operationalization: metric, unit, task, comparison.
2. Main result display with explicit units and uncertainty.
3. One direct, plain-English answer supported by the display.
4. More nuanced analysis: distributions, contrasts, outliers, failure examples.
5. Boundaries and caveats about causal attribution and generalization.

Use consistent terminology. If the primary metric is task success, do not casually switch to patch correctness. Report denominators and handle missingness. Tables should be interpretable without reading several pages of prose.

## 6. Discussion that adds insight

The Discussion is not a compressed duplicate of Results. It should answer:

- **Why** are some improvements larger or smaller than expected?
- Which mechanism do ablations or failures implicate?
- Under which conditions might a cheaper baseline be preferable?
- What does the evidence imply for practitioners or tool designers?
- Which assumptions limit deployment or interpretation?
- What does the study change about the current research understanding?

Label conjectures. Discuss surprises and negative findings even if they weaken the initial thesis. When performance differs between projects, consider heterogeneity instead of reporting only pooled averages.

## 7. Paragraph and language editing rules

- Topic sentence contains a proposition, not a generic transition.
- Every paragraph answers one question; remove sentences that do not develop it.
- Use concrete nouns and verbs. Replace "facilitates the leveraging of" with "uses" where accurate.
- Cut unnecessary qualifiers without removing important uncertainty.
- Prefer active voice when agency matters. Passive voice is acceptable when the experiment or result is central.
- Break long sentences, especially those carrying several parentheses, clauses, or semicolons.
- Use semicolons **rarely**. When an author uses more than one in a paragraph, consider separate sentences.
- Avoid unsupported terms: novel, pioneering, robust, comprehensive, unprecedented, optimal, guaranteed.
- Eliminate repeated motivation after it has been established. Use cross-references rather than re-explaining every component.
- Maintain abbreviation consistency, figure callouts, and exact RQ labeling.

## 8. Section acceptance checks

**Introduction:** Is novelty clear without reading Related Work? Is the motivating failure specific and grounded? Are contributions testable?

**Background:** Can the reader follow all approach notation without outside guessing? Is every definition justified? Is the running example last?

**Approach:** Does the overview diagram match actual component contracts? Are algorithms 10–15 readable lines? Does each component continue the example?

**Evaluation:** Do setup and implementation appear first and second? Does each RQ answer a claim? Are figures numerically reproducible and interpretations bounded? Is Discussion substantive?

**Related Work:** Does each family receive a fair comparison? Does the synthesis explain the gap rather than list citations?

**Conclusion:** Does it avoid new claims and reflect strengths, weaknesses, and implications accurately?
