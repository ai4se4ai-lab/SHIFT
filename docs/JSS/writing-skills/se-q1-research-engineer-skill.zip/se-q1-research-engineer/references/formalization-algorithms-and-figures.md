# Formalization, algorithms, diagrams, and running-example traces

## 1. Definition-first reasoning, explanation-first presentation

A useful formal definition captures a genuine ambiguity or dependency. Before every formalism, write **two to four motivating sentences**:

1. What current language is ambiguous or inadequate?
2. What relationship or property must be represented?
3. How does the upcoming definition enable the proposed method?

Then present this pattern:

> **Motivation.** A file-level dependency alone does not distinguish a proposed change from a verified effect. We therefore represent candidate edits and observed consequences separately. This distinction allows the later validator to reject unverified effects.
>
> **Definition 1 (Illustrative).** Define the relevant set and relation precisely here.
>
> **Interpretation.** Explain each symbol, domain, precondition, and non-guarantee in plain English.
>
> **Example.** Instantiate the definition using named elements of the shared running example.

The quoted illustration is merely a writing pattern, not a scientific claim about the user's eventual research topic.

## 2. Notation discipline

- Define each symbol at first use, including types, units, set domains, functions, and quantifier scopes.
- Distinguish total functions from partial functions and clarify what happens when inputs are missing.
- Do not overload one symbol for a method, metric, and artifact.
- Keep named functions stable between prose, equations, pseudocode, and implementation.
- Use only formalisms that actually determine an algorithm, an invariant, a measurement, or a conceptual distinction.
- State premises for proofs. When a result is supported only by illustrative reasoning, call it an intuition or proposition, not a theorem.

## 3. Algorithm rules

Main algorithms should contain **10–15 substantive numbered lines**, excluding caption, `Require`, `Ensure`, and explanatory comments. Prefer clear procedure calls over inlined equations:

```text
Algorithm: EvaluateChange(plan, context)
Require: Plan plan, repository context
Ensure: Decision with evidence or explicit failure
1  candidates ← GenerateCandidates(plan, context)
2  if candidates is empty then
3      return NoCandidate
4  evidence ← CollectEvidence(candidates, context)
5  valid ← FilterByConstraints(candidates, evidence)
6  if valid is empty then
7      return Rejected(evidence)
8  ranked ← RankCandidates(valid, evidence)
9  choice ← SelectCandidate(ranked)
10 decision ← Verify(choice, context)
11 RecordTrace(choice, evidence, decision)
12 return decision
```

This is a **format example only**. Do not insert it into an unrelated paper. Its operations would require actual definitions and an example trace before being scientifically appropriate.

For every algorithm, validate: preconditions, invariants, outputs, termination, error cases, asymptotic claims where meaningful, and mapping to implementation. Avoid one pseudocode line that hides an entire undefined scientific contribution. If a function is conceptually central, explain its mechanism or give another algorithm.

## 4. Overview architecture diagram

The first subsection of Approach must contain a **publication-grade diagram**. Distinguish:

- **Inputs and context:** data artifacts, policies, assumptions.
- **Core mechanism:** stages that constitute the new research contribution.
- **Subcomponents:** the necessary internal steps of each significant stage.
- **Outputs:** decisions, artifacts, traces, warnings, or results.
- **Feedback loops:** distinct edge styles or explicit labels for retries, human review, or updates.
- **Evaluation boundary:** separate the method under test from the independent oracle/evaluator.

Every line must have a semantic arrow label, not an unlabeled connection unless meaning is truly obvious. Use design tools suitable for vector output: TikZ, Graphviz, Mermaid as a draft, or SVG/PDF generated from code. Export crisp figures and verify readability at single-column or double-column journal width.

### Generic layout blueprint

```text
             Input artifacts and assumptions
                           |
                           | supplies
                           v
             +-------------------------------+
             | Core mechanism A              |
             |  A1: inspect   A2: transform  |
             +-------------------------------+
                           |
                           | produces candidates
                           v
             +-------------------------------+
             | Core mechanism B              |
             |  B1: check     B2: refine     |
             +-------------------------------+
                           |
                           | emits evidence + decision
                           v
                    Output + trace

         Independent evaluation harness
         (reads archived output, not private oracle)
```

Replace labels with project-specific terms and add real dependencies. Avoid implying that the evaluation harness is a component of the scientific method if it is only an experimental instrument.

## 5. Running-example traceability table

Maintain this table behind the manuscript while writing:

| Stage | Example input | Transformation or condition | Example output | Where shown |
|---|---|---|---|---|
| Background fixture | Issue, repo state, test | Define problem | Named initial state | Background, last subsection |
| Overview | Same fixture | End-to-end path | Target artifact and trace | Approach overview |
| Component A | Named input subset | Mechanism A | Explicit intermediate state | Approach A |
| Component B | Output of A | Mechanism B | Explicit intermediate state | Approach B |
| Algorithm 1 | A's artifacts | Numbered steps | Intermediate artifact | Near Algorithm 1 |
| Algorithm 2 | B's artifacts | Numbered steps | Decision or output | Near Algorithm 2 |
| Evaluation | Same fixture if suitable | Test mechanism | Verified or bounded observation | RQ/test case |

Do not report a toy trace as an empirical success. If the traced outcome is hypothesized, mark it hypothetical. For actual runs, link the example to a fixture and test artifact.

## 6. Formal claims and proof obligations

Before naming a result a theorem, document:

- Formal statement and quantified domains.
- Assumptions and why they are realistic.
- Relation to the algorithm actually implemented.
- Potential edge and counterexample cases.
- Proof strategy and complete proof or justified proof sketch.
- What remains outside the guarantee, especially with stochastic components or external tools.

Do not conflate soundness of a static check with correctness of arbitrary generated software. For probabilistic methods, avoid deterministic guarantees without explicit conditions.
