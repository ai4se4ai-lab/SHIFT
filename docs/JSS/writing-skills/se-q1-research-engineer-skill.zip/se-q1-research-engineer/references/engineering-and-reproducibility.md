# Research-grade engineering and reproducibility

## 1. Build the scientific mechanism, not a demo

Translate each conceptual component into an interface contract:

| Contract field | Question |
|---|---|
| Responsibility | Which scientific mechanism does it realize? |
| Inputs and preconditions | What data and invariants does it require? |
| Outputs and postconditions | What can downstream components rely on? |
| Error behavior | How are invalid input, timeouts, and partial results represented? |
| Determinism | Which parts can be seeded, which remain stochastic? |
| Observability | What logs and identifiers support claim traceability? |
| Unit tests | Which local invariant can be checked independently? |
| Ablation switch | Can this component be removed or replaced without rewriting the pipeline? |

Prefer one implementation of each scientifically significant interface. Do not duplicate baseline logic in a way that silently changes preprocessing.

## 2. Build stages

**Stage A — repository audit.** Inspect entry points, dependencies, existing tests, licenses, datasets, storage, and configurations. Write a map and note dangerous or destructive commands. Respect original structure where feasible.

**Stage B — executable vertical slice.** Make one genuine case run from input to validated output. Use a shared running-example fixture. Avoid placeholders that mimic evaluation success.

**Stage C — component contracts.** Implement transformation and verification steps separately. Include documented errors, type/schema checks, and regression tests.

**Stage D — baselines.** Use public baseline implementations or carefully documented reproductions. Match computational access, data splits, prompts when fair, models where appropriate, and postprocessing. Baselines must solve the same task.

**Stage E — experiments.** Build a command-line or workflow entry point for task/model/seed/config combinations. Capture attempt IDs, timestamps, git commit, package versions, environment, budgets, timeout, and completion status.

**Stage F — analysis.** Write scripts that ingest raw outputs, validate schemas, enforce eligibility, compute aggregates and uncertainty, and generate tables/figures. Never manually type empirical values into a paper when an automated path is possible.

**Stage G — reproducibility.** Rebuild in a clean environment or document why that was not possible. Record exact commands and failures. Publish a minimal example before a full benchmark if the benchmark has licensing restrictions.

## 3. Essential test pyramid

- **Unit:** parsing, graph operations, transformations, deterministic scoring, edge conditions, invalid input.
- **Property/metamorphic:** stable invariants across equivalent inputs, reorderings, irrelevant changes, idempotence if claimed.
- **Contract:** data shape and defined behavior at component boundaries.
- **Integration:** end-to-end running-example trace and at least one realistic artifact.
- **Regression:** a previously failing issue remains fixed.
- **Ablation:** disabling each proposed component changes only the intended mechanism.
- **Baseline parity:** the same dataset and evaluation rules apply to every method.
- **Reproducibility smoke:** one tiny experiment and analysis can run from documented setup.

Never claim tests pass without executing them. If unavailable, output expected tests and mark `not run`.

## 4. AI/LLM-specific safeguards

- Version the complete prompt, system instructions, tool permissions, decoding parameters, model endpoint, model identifier, and any retrieval source.
- Record codebase snapshot commit, candidate patch, context window, retrieval candidates, tests visible at prediction time, and tools invoked.
- Keep validation-only tests hidden from the system where required by benchmark protocol.
- Separate models used to generate, judge, and adjudicate results when possible. Note circular evaluator bias.
- Define response parsing, refusal, crashes, infrastructure failures, budget exhaustion, and retries before measuring outcomes.
- Distinguish **attempt-level** observations from **task-level** success. Do not inflate sample size through retries or multiple prompts on the same issue.
- Avoid mixing training, tuning, retrieval index, and evaluation repositories in ways that create leakage.
- For human-in-the-loop experiments, record what humans were allowed to see and how decisions were collected.
- Report actual inference, token, compute, wall-clock, and engineering costs where they matter, with units and accounting assumptions.

## 5. Reproducible run identity

Define a run key such as:

`study_id / revision / dataset_version / project / task_id / method / config_hash / model_version / seed / replicate`

The key should be unique for independent executions. Link retries to a parent attempt and explain whether they belong to a policy-level run. Keep raw files immutable and place corrections in derived datasets with recorded rationale.

## 6. Configuration and artifact checklist

Record: source commit; package lockfile; OS/container image; CPU/GPU/RAM; API model versions and access dates where appropriate; benchmark and license version; data split hash; seeds; prompt hash; flags and thresholds; timeout/retry policy; budget; executable scripts; parser version; statistical analysis code; output manifest; exclusions; failure logs.

Provide `README` commands for installation, smoke test, baselines, full experiments, analysis, and paper build. Where execution is prohibitively expensive or access restricted, clearly distinguish reproducible **analysis from archived raw outputs** from reproducible **end-to-end generation**.

## 7. Common engineering failures and fixes

| Failure | Required remedy |
|---|---|
| Only a screenshot or demo exists | Provide executable input/output path and tests |
| Algorithm and implementation differ | Create a step-by-step pseudocode-to-function mapping and verify |
| Results vary across restarts without explanation | Record seeds, nondeterminism, and repeated trials |
| Manual edits to CSV or tables | Generate derived files with scripts and audit trail |
| Baselines have different input access | Normalize comparison or explicitly narrow the claim |
| Failed tasks silently disappear | Include failure denominator and reporting policy |
| Model judges its own outputs without safeguards | Independent adjudication, calibration, and reliability evidence |
| Project-specific hacks dominate the paper | Separate core mechanism, configurations, and external integration |
