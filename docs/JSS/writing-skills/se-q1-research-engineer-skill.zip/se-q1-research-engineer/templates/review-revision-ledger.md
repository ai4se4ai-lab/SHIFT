# Scientific Review and Revision Ledger

Study: [title]
Revision: [revision ID]
Actual review type: AI role-based internal / external reviewer report / coauthor / other

> Internal role-play is not independent external peer review. Preserve exact external reviewer identifiers if available.

## Review round summary

| Round | Perspective | Date | Blockers | Majors | Minors | Revised? | Rechecked? |
|---|---|---|---|---|---|---|---|
| R0 | Area editor | | | | | | |
| R1 | Methodology | | | | | | |
| R2 | Formal/technical | | | | | | |
| R3 | Engineering/reproducibility | | | | | | |
| R4 | Scientific writing | | | | | | |
| R5-A | Mock reviewer: novelty | | | | | | |
| R5-B | Mock reviewer: rigor | | | | | | |
| R5-C | Mock reviewer: transparency | | | | | | |
| R6 | Final editorial audit | | | | | | |

## Issue log

| ID | Severity | Section/file/line | Finding with evidence | Required revision | Verification method | Status | Changed artifact |
|---|---|---|---|---|---|---|---|
| | | | | | | OPEN | |

## Revision pass

Pass: [1/2/3+]

**Original concerns addressed:**

**Edits made and diff paths:**

**Results and claims preserved or legitimately changed:**

**Tests, builds, and analyses actually rerun:**

**New regressions or concerns introduced:**

**Remaining blockers or major issues:**

**Decision:** NOT READY / NEEDS MAJOR WORK / READY FOR SUBMISSION AUDIT
