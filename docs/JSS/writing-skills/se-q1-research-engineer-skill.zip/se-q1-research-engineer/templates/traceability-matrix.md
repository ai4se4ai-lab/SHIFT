# Scientific Traceability Matrix

| ID | Problem/claim | Definition or assumption | Approach component | Algorithm | Code/tests | RQ/proof | Result artifact | Manuscript claim | Review status |
|---|---|---|---|---|---|---|---|---|---|
| C1 | | | | | | | | | |
| C2 | | | | | | | | | |
| C3 | | | | | | | | | |

## Running example ledger

| Step | Named input | Expected intermediate output | Verification source | Background/Approach reference |
|---|---|---|---|---|
| Initial state | | | | |
| Component 1 | | | | |
| Component 2 | | | | |
| Final state | | | | |

## Dependency audit

- When a **definition** changes: recheck algorithms, implementation, proofs, and example.
- When a **metric** changes: recheck dataset, analysis, all tables/figures, abstract, and conclusion.
- When a **baseline** changes: recheck fairness, comparisons, interpretation, related work.
- When a **figure** changes: recheck diagram edges, prose references, captions, and section consistency.
