# Evaluation Protocol — [Study]

Status: PLANNED / VERSIONED / EXECUTING / COMPLETE
Protocol version and date: [version/date]
Primary analysis frozen before outcomes? [YES / NO / NOT APPLICABLE]

## 1. Goals and research questions

For each RQ, define the **estimand**, unit of analysis, and a conclusion you would draw from negative evidence. Avoid vague questions such as "Is our method better?" without defining the outcome and population.

| RQ | Contribution | Estimand or formal property | Unit | Comparator | Primary outcome | Decision rule | Analysis |
|---|---|---|---|---|---|---|---|
| RQ1 | | | | | | | |
| RQ2 | | | | | | | |
| RQ3 | | | | | | | |

## 2. Materials and inclusion

- Corpus/benchmark origin and version:
- Repository/task selection procedure:
- Inclusion and exclusion criteria established before measuring outcomes:
- Data leakage and benchmark contamination checks:
- Ground truth / oracle source and reliability:
- Human coding and adjudication protocol, if applicable:
- License, privacy, and ethics constraints:

## 3. Methods and fair comparisons

- Proposed conditions:
- Baselines and credible source implementations:
- Why these baselines are state-of-the-art or otherwise necessary:
- Access to tools, code, model, context, labels, test suites:
- Tuning, data partitions, prompt, token, compute, and human-time budgets:
- Ablations and expected diagnostic meaning:
- Negative controls and edge conditions:

## 4. Execution and reliability

- Environment and pinned versions:
- Experimental unit:
- Nested levels / repeated measures:
- Randomization, matching, and seeds:
- Independent repetitions per unit and justification:
- Timeouts, retries, failures, and exclusions:
- Sample size or precision justification:
- Run/attempt accounting and IDs:
- Expected raw schema and integrity checks:

## 5. Outcomes and statistical analysis

- Primary metrics, formulas, denominators, units:
- Secondary metrics and resources/cost measures:
- Aggregation rules and uncertainty method:
- Effect size and confidence interval plan:
- Hypothesis tests and assumptions if used:
- Handling ties, missing outcomes, censoring, clustering:
- Multiple comparisons policy:
- Preplanned heterogeneity and sensitivity analyses:
- Exploratory analysis policy:

## 6. Threats and planned mitigations

| Construct | Internal | External | Conclusion | Reproducibility / ethics |
|---|---|---|---|---|
| | | | | |

## 7. Result traceability

| Reported result | Raw run files | Validation script | Analysis command | Generated table/figure | Claim ID |
|---|---|---|---|---|---|
| | | | | | |

## 8. Reporting checklist

- [ ] Setup is first Evaluation subsection
- [ ] Implementation is second Evaluation subsection
- [ ] Primary and secondary outcomes are distinguished
- [ ] Every table has denominators and appropriate uncertainty
- [ ] All failures, retries, timeouts, and excluded tasks are accounted for
- [ ] No synthetic or illustrative values appear as measured findings
- [ ] A substantive Discussion ends the Evaluation section
- [ ] Raw-to-paper provenance is reproducible
