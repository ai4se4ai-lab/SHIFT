# Submission Readiness Scorecard

Rate each criterion from 0 to 4 using evidence:

- **0 — Absent or invalid:** required content missing, unsound, or unverifiable.
- **1 — Major weakness:** insufficient support or serious credibility concern.
- **2 — Promising but incomplete:** viable idea with important unresolved problems.
- **3 — Strong:** substantively sound, clear, with bounded limitations.
- **4 — Exceptional:** highly convincing, independently auditable, strong on critical counterarguments.

| Dimension | 0–4 | Specific evidence | Main risk | Fix and verification |
|---|---|---|---|---|
| Novelty vs nearest prior art | | | | |
| Problem significance and real-world relevance | | | | |
| Contribution clarity and falsifiability | | | | |
| Formal definitions and algorithm correctness | | | | |
| Research software quality and reproducibility | | | | |
| Evaluation design and baseline fairness | | | | |
| Statistical or logical validity | | | | |
| Robustness, ablations, negative cases | | | | |
| Intro, Background, Approach continuity | | | | |
| Running-example completeness and usability | | | | |
| Readability, figures, and diagrams | | | | |
| Related Work coverage and fairness | | | | |
| Claims-to-evidence traceability | | | | |
| Limitations, threats, ethics, licenses | | | | |
| Target journal fit and formatting | | | | |

**Important:** Do not average ratings into a declaration of readiness. A single integrity issue, central missing experiment, invalid proof, or unverified key result blocks submission readiness regardless of the total.

## Three-reviewer decision record

Reviewer A (novelty/significance): [summary, major objections, recommendation]

Reviewer B (methods/formal rigor): [summary, major objections, recommendation]

Reviewer C (clarity/replicability): [summary, major objections, recommendation]

Editor synthesis: [common blocking concerns, priorities, closure conditions]

Round number: [number]
All blockers verified resolved? [yes/no]
All major findings resolved or defensibly dispositioned? [yes/no]
Tests, results, citations, paper build checked? [details, actual outcomes]
Final status: [NOT READY / NEEDS MAJOR WORK / READY FOR SUBMISSION AUDIT]
