# Research Brief — [Study title]

> Copy this file into the project and fill with evidence. Do not treat planned numbers as observed results.

## Research identity

- Working title:
- Target journal and verified author-guidelines URL/date:
- Study type: empirical / experimental / theoretical / mixed / other
- Intended readers:
- Existing repository and source files:
- Authorized data and source boundaries:
- Main language, toolchain, artifact format:
- User-defined constraints and deadlines:

## Problem and contribution

**One-sentence problem:**

**Specific failure scenario:**

**Evidence the failure matters** (source or observation and verification status):

**Current method family and limiting assumption:**

**Research gap (precisely bounded):**

**Central insight:**

**Proposed mechanism in one paragraph:**

**Three or fewer main contributions** (type, novelty boundary, expected validation):

1. C1:
2. C2:
3. C3:

**Explicit non-claims and assumptions:**

## Research questions and evidence

| RQ or proposition | Contribution | Measurement/proof | Comparator | What would refute it? |
|---|---|---|---|---|
| RQ1 | | | | |
| RQ2 | | | | |
| RQ3 | | | | |

## Evaluation feasibility

- Benchmarks and selection rules:
- Strongest relevant baselines:
- Experimental unit and repeated-measure plan:
- Resources, compute budget, and environment:
- Primary metrics and intended uncertainty analysis:
- Human data or annotation requirements:
- Anticipated leakage, oracle, and validity risks:
- Artifacts accessible now:
- Evidence unavailable now:

## Conceptual map

- Required Background concepts and definitions (dependency order):
- Running example candidate and actual fixture availability:
- Approach main components and subcomponents:
- Annotated data/control edges for overview figure:
- Algorithms and their roles (10–15 substantive lines each):

## Research reviewer attack

- Closest work that could reduce novelty:
- Most dangerous simple baseline:
- Main concern about validity or generalization:
- Cheapest decisive falsification experiment:
- Risks that could block submission:

## Project state

- Current mode: DESIGN / BUILD / MEASURE / WRITE / REVIEW / REVISE / AUDIT
- Current gates: G0=?, G1=?, G2=?, G3=?, G4=?, G5=?, G6=?, G7=?, G8=?
- Next action and expected output:
