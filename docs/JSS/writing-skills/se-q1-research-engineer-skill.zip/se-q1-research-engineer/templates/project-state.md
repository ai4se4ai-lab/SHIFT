# Research Project State

Updated: [date and timezone]
Project: [study]
Target venue: [journal, guidelines verified on date]
Study mode: [DESIGN | BUILD | MEASURE | WRITE | REVIEW | REVISE | AUDIT]

## Canonical artifacts

| Type | Path | Current version | Verified? |
|---|---|---|---|
| Research contract | | | |
| Paper source | | | |
| Bibliography | | | |
| Proposed approach code | | | |
| Baseline code | | | |
| Test suite | | | |
| Evaluation protocol | | | |
| Raw outputs | | | |
| Analysis scripts | | | |
| Reproducibility instructions | | | |
| Claims-evidence ledger | | | |
| Review ledger | | | |

## Decisions locked for this study

- Problem and novelty boundary:
- Definitions and notation conventions:
- Running-example identity and test fixture:
- Baselines, metrics, and dataset versions:
- Unit of analysis, repetitions, and exclusions:
- Reporting conventions and figure/table labels:

## Gate dashboard

| Gate | Status PASS / FAIL / PARTIAL / NOT CHECKED | Evidence or blocker | Next verification |
|---|---|---|---|
| G0 Problem | NOT CHECKED | | |
| G1 Novelty | NOT CHECKED | | |
| G2 Code | NOT CHECKED | | |
| G3 Theory | NOT CHECKED | | |
| G4 Exposition | NOT CHECKED | | |
| G5 Evaluation | NOT CHECKED | | |
| G6 Scholarship | NOT CHECKED | | |
| G7 Review | NOT CHECKED | | |
| G8 Release | NOT CHECKED | | |

## Last action / validation

- What changed:
- Tests executed and their actual outcomes:
- Analyses executed and their actual outputs:
- Manuscript build executed and outcome:
- Unavailable tests or unverified claims:
- Open high-severity review items:
- Next smallest action:
