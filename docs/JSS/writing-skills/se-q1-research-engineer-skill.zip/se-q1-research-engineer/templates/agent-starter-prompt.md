# Reusable Agent Starter Prompt

Use this with your research agent after installing the skill. Adapt the bracketed fields.

> Apply the `se-q1-research-engineer` skill to the study in [project path or paper files].
>
> Target journal: [TSE / EMSE / JSS / IST / other].
> Current mode: [DESIGN / BUILD / MEASURE / WRITE / REVIEW / REVISE / AUDIT].
> Main study question: [brief statement].
> Constraints: [authorized sources, computing budget, journal formatting, code stack, immutable results].
>
> First inspect all relevant project artifacts and update the research brief and project state. Identify the central scientific gap and nearest competing methods, then work only on the requested mode. Follow the required manuscript section order, with the Running Example at the end of Background, the annotated Overview diagram first in Approach, and Setup then Implementation first in Evaluation. Make algorithms 10–15 readable conceptual lines with a running-example trace after each one. Conduct the relevant critique–revision–recheck rounds. Never fabricate evidence, citations, benchmarks, or test outcomes. Return changed files, validated checks, unresolved issues, and next action.

## Examples of scoped follow-up requests

**New idea:**
> DESIGN mode. Create two competitive research formulations and identify the strongest falsification experiment before selecting one.

**Existing codebase:**
> BUILD mode. Audit the implementation against the approach definitions. Repair correctness issues, add regression tests, and produce a reproducible experiment command. Do not modify measured datasets.

**Manuscript drafting:**
> WRITE mode. Produce Introduction, Background, and Approach in LaTeX. Define all symbols before use and keep the running example consistent throughout.

**Evaluation work:**
> MEASURE mode. Use only actual experimental artifacts and rerunnable analysis. Report failure counts, units of analysis, effect sizes and intervals. Mark missing runs openly.

**Critical revisions:**
> REVIEW then REVISE modes. Simulate novelty, methodology, and reproducibility reviewers. Classify concerns by severity, fix them, and recheck evidence and paper consistency. Keep an issue ledger and explain unresolved blockers.
